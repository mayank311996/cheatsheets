'use strict';

console.log('Functions');

exports.handler = (event, context, callback) => {
    console.log('Received event:',  JSON.stringify(event, null, 2));
    console.log('OutputTemp :',     event.Temperature);
    console.log('OutputHumid : =',  event.Humidity); 
	console.log('OutputTime :',     event.Time);
    console.log('OutputDevice : =', event.Device_ID); 
    callback(null, event);  // Echo back value, without .member specifier all logs displayed

};

